<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <article>
                <h1><?php print $title; ?></h1>
                <p><?php print render($content['body']); ?></p>
            </article>
        </div>
    </div>
</div>